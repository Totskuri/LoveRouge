require("conf")
local MapFactory = require "MapFactory"
local PlayerController = require "PlayerController"
local CameraController = require "CameraController"

function love.load()
	CameraController:scale(0.5) -- 0.5 equals 2x
	love.window.setMode(windowWidth, windowHeight, {})
	
	MapFactory:generateMap()

	love.graphics.setDefaultFilter("nearest", "nearest")
	floorTile = love.graphics.newImage("assets/floor.png")
	wallTile = love.graphics.newImage("assets/wall.png")
end

function love.update(dt)
    PlayerController:movePlayer(dt)
end

function love.draw()
    CameraController:set()
	MapFactory:drawMap(floorTile, wallTile)
	PlayerController:drawPlayer()
    CameraController:unset()
end

function love.keypressed(key)
	if key == "up" then
        if MapFactory:testBounds(0, -1) then
			PlayerController:setY(PlayerController:getY() - blockSize)
			playerMoved()
		end
	elseif key == "down" then
		if MapFactory:testBounds(0, 1) then
			PlayerController:setY(PlayerController:getY() + blockSize)
			playerMoved()
		end
	elseif key == "left" then
		if MapFactory:testBounds(-1, 0) then
			PlayerController:setX(PlayerController:getX() - blockSize)
			playerMoved()
		end
	elseif key == "right" then
		if MapFactory:testBounds(1, 0) then
			PlayerController:setX(PlayerController:getX() + blockSize)
			playerMoved()
		end
	end
end

function playerMoved()
	MapFactory:calcFOV()
end