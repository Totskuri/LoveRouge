--general
windowWidth = 800
windowHeight = 600

--map
blockSize = 16
mapWidth = 50
mapHeight = 50
mapTiles = {
    floor = 1,
    wall = 2,
}
fovDarken = 0.25

--fov
lightRadius = 13