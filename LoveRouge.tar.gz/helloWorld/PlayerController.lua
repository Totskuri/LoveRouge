require("conf")
local CameraController = require "CameraController"

local PlayerController = {}

local player = {
    posX = 0,
    posY = 0,
    moveX = 0,
    moveY = 0,
    speed = 10
}

function PlayerController:getX()
    return player.posX
end

function PlayerController:setX(x)
    player.posX = x
end

function PlayerController:getY()
    return player.posY
end

function PlayerController:setY(y)
    player.posY = y
end

function PlayerController:setStartingLocation(x, y)
    player.posX = x * blockSize
    player.posY = y * blockSize
    player.moveX = x * blockSize
    player.moveY = y * blockSize
end

function PlayerController:getPlayer()
    return player
end

function PlayerController:drawPlayer()
    love.graphics.rectangle("fill", player.moveX, player.moveY, blockSize, blockSize)
end

function PlayerController:movePlayer(dt)
    player.moveY = player.moveY - ((player.moveY - player.posY) * player.speed * dt)
    player.moveX = player.moveX - ((player.moveX - player.posX) * player.speed * dt)
    CameraController:setPosition(player.moveX - (windowWidth / 4) + (blockSize/2), player.moveY - (windowHeight / 4) + (blockSize/2))
end

return PlayerController