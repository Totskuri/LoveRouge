local ROT = require 'lib.rotLove-develop.src.rot'
local FOV = require 'lib.Lua-FOV-master.rsfov'
require("conf")
local PlayerController = require "PlayerController"

local MapFactory = {}

local map = {}
local grid = {} --grid that is generated
local visibleGrid = {} --grid visible to player
local fovGrid = {} --grid for fov and light
local startLocFound = false

--[[
    Tile types - TODO: move into conf file or similar
    -1  nothing
    0   dark floor
    1   dark wall
    2   dark door

    100 light floor
    101 light wall
    102 light door
--]]

function MapFactory:generateMap()
    map = ROT.Map.Brogue(mapHeight, mapWidth)
    map:create(mapCallback)
    MapFactory:calcFOV()
end

function MapFactory:drawMap(floorTile, wallTile)
    --set tiles
    for x=1, mapHeight do
        for y = 1, mapWidth do
            if fovGrid[x..','..y] == 1 then
                love.graphics.setColor(1 * fovDarken, 1 * fovDarken, 1 * fovDarken)
                love.graphics.draw(wallTile, x * blockSize, y * blockSize)
                love.graphics.setColor(1, 1, 1)
            elseif fovGrid[x..','..y] == 0 or fovGrid[x..','..y] == 2 then
                love.graphics.setColor(1 * fovDarken, 1 * fovDarken, 1 * fovDarken)
                love.graphics.draw(floorTile, x * blockSize, y * blockSize)
                love.graphics.setColor(1, 1, 1)
            elseif fovGrid[x..','..y] == 101 then
                love.graphics.draw(wallTile, x * blockSize, y * blockSize)
            elseif fovGrid[x..','..y] == 100 then
                love.graphics.draw(floorTile, x * blockSize, y * blockSize)
            end
        end
    end
end

function MapFactory:calcFOV()
    fovGrid = shallowcopy(visibleGrid)
    FOV(PlayerController.getX() / blockSize, PlayerController.getY() / blockSize, lightRadius, isTransparent, onVisible, 0, math.pi*2, 10)
end

--copy table
function shallowcopy(orig)
    local orig_type = type(orig)
    local copy
    if orig_type == 'table' then
        copy = {}
        for orig_key, orig_value in pairs(orig) do
            copy[orig_key] = orig_value
        end
    else -- number, string, boolean, etc
        copy = orig
    end
    return copy
end

--enter tile info into grid
function mapCallback(x, y, val)
    if val == 2 or val == 0 then
        grid[x..','..y]=0
        if (not startLocFound) then
            startLocFound = true
            PlayerController:setStartingLocation(x, y)
        end
    else
        grid[x..','..y] = 1
    end
    visibleGrid[x..','..y] = -1 --mark all tiles in map as nothing
end

--check if you can move to tile
function MapFactory:testBounds(x, y)
    if grid[((PlayerController:getX() / blockSize) + x)..','..((PlayerController:getY() / blockSize) + y)] == 1 then
		return false
    end
	return true
end

--check if tile is visible to player
function isTransparent(x, y)
    if grid[x..','..y] == 0 or grid[x..','..y] == 2 then
        return true
    end
    return false;
end

--when tile is visible to player
--convert to light tile
function onVisible(x,y)
    if grid[x..','..y] == 0 or grid[x..','..y] == 2 then
        fovGrid[x..','..y] = 100
        visibleGrid[x..','..y] = 0
    elseif grid[x..','..y] == 1 then
        fovGrid[x..','..y] = 101
        visibleGrid[x..','..y] = 1
    end
end
    

return MapFactory