Monster = {}
Monster.__index = Monster
function Monster:Create()
    local this =
    {
        name = "orc",
        health = 10,
        attack = 3
    }
    setmetatable(this, Monster)
    return this
end

function Monster:WarCry()
    print(self.name .. ": GRAAAHH!!!")
end

monster_1 = Monster:Create()
monster_1:WarCry() -- > "orc: GRAAAHH!!!"

--Note that in Create function we set the metatable to the Monster. But we call Create with the : syntax which means we can rewrite the setmetatable line to
-- setmetatable(this, self)


--STATIC FIELDS 

SomeClass = { id = "some_class" }
SomeClass.__index = SomeClass
function SomeClass:Create()
    local this = {}
    setmetatable(this, SomeClass)
    return this
end

c1 = SomeClass:Create()
c2 = SomeClass:Create()

print(c1.id) -- "some_class"
print(c2.id) -- "some_class"
