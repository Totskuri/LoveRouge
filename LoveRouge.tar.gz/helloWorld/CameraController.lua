local CameraController = {}

camera = {
    x = 0,
    y = 0,
    scaleX = 1,
    scaleY = 1,
    rotation = 0
}

function CameraController:getCamera()
    return camera
end

function CameraController:set()
  love.graphics.push()
  love.graphics.rotate(-camera.rotation)
  love.graphics.scale(1 / camera.scaleX, 1 / camera.scaleY)
  love.graphics.translate(-camera.x, -camera.y)
end

function CameraController:unset()
  love.graphics.pop()
end

function CameraController:move(dx, dy)
  camera.x = camera.x + (dx or 0)
  camera.y = camera.y + (dy or 0)
end

function CameraController:rotate(dr)
  camera.rotation = camera.rotation + dr
end

function CameraController:scale(sx, sy)
  sx = sx or 1
  camera.scaleX = camera.scaleX * sx
  camera.scaleY = camera.scaleY * (sy or sx)
end

function CameraController:setPosition(x, y)
  camera.x = x or camera.x
  camera.y = y or camera.y
end

function CameraController:setScale(sx, sy)
  camera.scaleX = sx or camera.scaleX
  camera.scaleY = sy or camera.scaleY
end

return CameraController