Libraries to consider:
    rotLove - rot.js port to love2d